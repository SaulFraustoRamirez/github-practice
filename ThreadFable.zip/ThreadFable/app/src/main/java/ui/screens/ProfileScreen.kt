package ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ProfileScreen() {
    Column(modifier = Modifier.padding(20.dp)) {

        Text(
            text = "Your Profile",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(16.dp))

        Row {
            Text("Username: Cassandra")
        }

        Spacer(Modifier.height(8.dp))

        Row {
            Text("Stories Created: 0")
        }
    }
}
