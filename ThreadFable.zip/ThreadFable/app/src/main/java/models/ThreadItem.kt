package models

data class ThreadItem(
    val id: String,
    val title: String,
    val preview: String
)

